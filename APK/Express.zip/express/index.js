const express = require('express')
const mongoose = require('mongoose')
const app = express()
const authRouter = require('./authRouter')
const port = 3000

app.use(express.json())

app.get('/', (req, res) => {
    res.send('Hello')
})

app.use('/api', authRouter)


app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

mongoose.connect('mongodb://localhost:27017/express')